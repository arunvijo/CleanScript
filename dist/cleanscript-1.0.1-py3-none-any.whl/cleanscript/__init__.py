from .optimizer import optimize_code

__version__ = "0.1.0"
